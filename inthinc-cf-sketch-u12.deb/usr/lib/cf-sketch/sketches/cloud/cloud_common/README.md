# Cloud::Services::Common version 1

License: MIT
Tags: cfdc, cloud, aws, openstack
Authors: Ted Zlatanov <tzz@lifelogs.com>

## Description
Common library for cloud services

## Dependencies
CFEngine::dclib, CFEngine::stdlib

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

