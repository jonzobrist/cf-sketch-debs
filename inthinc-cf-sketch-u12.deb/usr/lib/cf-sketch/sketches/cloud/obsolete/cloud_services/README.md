# Cloud::Services version 1.1

License: MIT
Tags: cfdc
Authors: Ted Zlatanov <tzz@lifelogs.com>

## Description
Manage EC2 and VMware instances

## Dependencies
CFEngine::stdlib

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

