# CFEngine::Blueprint version 1.0.0

License: MIT
Tags: cfdc, blueprint
Authors: CFEngine AS

## Description
Library to connect Blueprint sketches with Design Center

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

