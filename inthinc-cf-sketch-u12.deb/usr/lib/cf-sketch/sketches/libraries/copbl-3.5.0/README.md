# CFEngine::stdlib::3.5.0 version 110

License: LGPL
Tags: cfdc
Authors: CFEngine AS

## Description
The portions of the CFEngine standard library (also known as COPBL) that are only compatible with 3.5.0 and higher

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

