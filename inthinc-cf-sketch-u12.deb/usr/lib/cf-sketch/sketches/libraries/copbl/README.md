# CFEngine::stdlib version 111

License: LGPL
Tags: cfdc
Authors: CFEngine AS, ahdinosaur

## Description
The portions of the CFEngine standard library (also known as COPBL) that are compatible with 3.4.0 releases

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

