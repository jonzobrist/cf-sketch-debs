# CFEngine::dclib::3.5.0 version 3.5.0

License: MIT
Tags: cfdc, stdlib
Authors: CFEngine AS

## Description
Design Center standard library for CFEngine 3.5.0 and higher

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

