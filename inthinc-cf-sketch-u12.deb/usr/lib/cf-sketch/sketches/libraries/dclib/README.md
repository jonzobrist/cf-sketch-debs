# CFEngine::dclib version 1.0.0

License: MIT
Tags: cfdc, stdlib
Authors: CFEngine AS

## Description
Design Center standard library

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

