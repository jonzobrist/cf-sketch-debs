# Library::Hardware::Info version 1.2

License: MIT
Tags: cfdc
Authors: Nick Anderson <nick@cmdln.org>, Trondham via cfengineers.org

## Description
Discover hardware information

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

