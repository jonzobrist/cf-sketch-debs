# Yale::stdlib version 1.0.0

License: MIT
Tags: cfdc, yale
Authors: Yale University

## Description
Yale standard library

## Dependencies
none

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

