# Monitoring::Snmp::hp_snmp_agents version 1.1

License: MIT
Tags: cfdc
Authors: Nick Anderson <nick@cmdln.org>

## Description
Install and optionally configure hp-snmp-agents

## Dependencies
CFEngine::stdlib

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

