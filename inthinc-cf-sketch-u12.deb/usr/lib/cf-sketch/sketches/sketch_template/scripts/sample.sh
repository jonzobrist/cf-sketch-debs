#!/bin/sh

echo this is fun
