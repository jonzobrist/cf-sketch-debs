This directory contains "old-style" sketches that have not yet been
ported to the structure needed by cf-sketch to manage them. As they
are ported, they should be moved to their main location again.

For porting guidance, please see
[How to write a new sketch](https://github.com/cfengine/design-center/wiki/How-to-write-a-new-sketch).
