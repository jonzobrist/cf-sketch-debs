A community global bundle for binaries and other system paths would be a time
saver.
