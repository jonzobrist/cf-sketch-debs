# Monitoring::nagios_plugin_agent version 1.04

License: MIT
Tags: cfdc
Authors: Robert Carleton <rbc@rbcarleton.com>, Nick Anderson <nick@cmdln.org>, Ted Zlatanov <tzz@lifelogs.com>

## Description
Run Nagios plugins and optionally take action

## Dependencies
CFEngine::stdlib

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

