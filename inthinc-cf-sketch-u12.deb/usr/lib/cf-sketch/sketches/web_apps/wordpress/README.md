# WebApps::wordpress_install version 1

License: MIT
Tags: cfdc
Authors: Aleksey Tsalolikhin <atsaloli.tech@gmail.com>, Diego Zamboni <diego.zamboni@cfengine.com>

## Description
Install and configure Wordpress

## Dependencies
CFEngine::stdlib

## API
none

## SAMPLE USAGE
See `test.cf` or the example parameters provided

