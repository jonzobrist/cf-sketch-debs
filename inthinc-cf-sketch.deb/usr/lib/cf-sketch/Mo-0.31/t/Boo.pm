package Boo;
use Mo;

has 'buff';

1;
